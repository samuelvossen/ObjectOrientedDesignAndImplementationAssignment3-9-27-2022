module VossenICS372PA3 {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
